This is a whatsapp bombing software made using python.

Steps to use:-

1) Download and install python in your system.
2) Run main.py file.
3) Enter Message and number of messages you want to send.
4) Whatsapp web will open.
5) Quickly open the chat window of the contact to whom you want to send messages.
6) After 10seconds messages will start to type and go automaticaly.

Note:- 

Once the typing starts don't put the cursor anywhere else or it will start writting their.

Before use your whatsapp web should be registered to the browser.

---------Do Not Misuse--------- 
